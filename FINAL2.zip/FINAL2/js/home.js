var bigFood=document.getElementByClassName('home');
window.addEventListener('scroll', BfShowUpLate);

function BfShowUpLate(){
  setTimeout(BfShowUp,4000);
